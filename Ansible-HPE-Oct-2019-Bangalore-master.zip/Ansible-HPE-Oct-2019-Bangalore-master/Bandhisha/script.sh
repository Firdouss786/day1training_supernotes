#!/bin/sh
#This is a comment!
echo Hello World >>result.txt
# This is a comment, too!

