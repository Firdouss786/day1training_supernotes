# Ansible-HPE-Oct-2019-Bangalore
Ansible-HPE-Oct-2019-Bangalore

[FIRST]git clone https://github.com/devopsschool-lab-exercise/Ansible-HPE-Oct-2019-Bangalore.git

git pull origin master

git add .

git commit -m"Adding WHY?

git push origin master
